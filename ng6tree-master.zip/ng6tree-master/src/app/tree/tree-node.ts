export interface TreeNode {
    name: string;
    showChildren: boolean;
    children: any[];
}